<h1 align="center">ADMIN-MASTER</h1>

版本：`2.0`（日期：2020-03-16）

<br/>

#### Build Setup
``` bash
# 安装依赖
npm i / cnpm i

# 启动服务 localhost:8088
npm run dev

# 构建生产环境
npm run build
```
